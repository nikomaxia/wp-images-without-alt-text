<?php
/*
Plugin Name: Εύρεση εικόνων χωρίς Alt Text
Description: Εντοπίζει όλες τις εικόνες χωρίς Alt Text και επιτρέπει την εξαγωγή σε Excel με ενεργά links.
Version: 1.5
Author: D.Tsagkrinos
Text Domain: images-without-alt-text
*/

// Έξοδος αν προσπελαστεί απευθείας
if (!defined('ABSPATH')) {
    exit;
}

// Φόρτωση της βιβλιοθήκης PhpSpreadsheet
require_once plugin_dir_path(__FILE__) . 'vendor/autoload.php';

// Χρήση του PhpSpreadsheet
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Προσθήκη του admin menu
function iwat_custom_admin_menu() {
    add_menu_page(
        'Εύρεση εικόνων χωρίς Alt Text', // Τίτλος της σελίδας
        'Εύρεση εικόνων χωρίς Alt Text', // Τίτλος μενού
        'manage_options',                // Δικαιώματα
        'images-without-alt-text',       // Slug μενού
        'iwat_display_images_without_alt_text', // Συνάρτηση callback
        'dashicons-format-image',        // Εικονίδιο
        6                                // Θέση
    );
}
add_action('admin_menu', 'iwat_custom_admin_menu');

// Εμφάνιση της admin σελίδας
function iwat_display_images_without_alt_text() {
    // Έλεγχος αν ζητήθηκε εξαγωγή
    if (isset($_POST['action']) && $_POST['action'] === 'export_images_without_alt_text') {
        iwat_export_images_without_alt_text();
        exit;
    }

    // Λήψη όλων των εικόνων χωρίς Alt Text
    $images_without_alt = iwat_get_images_without_alt_text();

    // Εμφάνιση του περιεχομένου της admin σελίδας
    echo '<div class="wrap">';
    echo '<h1>Εύρεση εικόνων χωρίς Alt Text</h1>';
    echo '<p>Development: Dimitris Tsagkrinos</p>';
    echo '<p>v1.5</p>';

    if (!empty($images_without_alt)) {
        // Φόρμα για εξαγωγή
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        echo '<input type="hidden" name="action" value="export_images_without_alt_text">';
        wp_nonce_field('export_images_without_alt_text_nonce', 'export_images_nonce');
        submit_button('Export to Excel');
        echo '</form>';

        // Εμφάνιση της λίστας
        echo '<ul>';
        foreach ($images_without_alt as $image) {
            echo '<li>';
            echo '<strong>' . esc_html($image['Title']) . ':</strong> ';
            echo '<a href="' . esc_url($image['URL']) . '" target="_blank">' . esc_html($image['URL']) . '</a>';
            echo ' (Τίτλος Άρθρου: ';
            if ($image['ParentPostID']) {
                echo '<a href="' . esc_url($image['ParentPostURL']) . '" target="_blank">' . esc_html($image['ParentPostTitle']) . '</a>';
            } else {
                echo 'Δεν ανήκει σε άρθρο';
            }
            echo ', Ημ/νια Δημοσίευσης: ' . esc_html($image['ParentPostDate']) . ', Συντάκτης: ' . esc_html($image['ParentPostAuthor']) . ')';
            echo '</li>';
        }
        echo '</ul>';
    } else {
        echo '<p>Όλες οι εικόνες έχουν Alt Text.</p>';
    }

    echo '</div>';
}

// Συνάρτηση για λήψη εικόνων χωρίς Alt Text
function iwat_get_images_without_alt_text() {
    $args = array(
        'post_type'      => 'attachment',
        'post_mime_type' => 'image',
        'post_status'    => 'inherit',
        'posts_per_page' => -1,
    );

    $images = get_posts($args);

    $images_without_alt = array();

    foreach ($images as $image) {
        $alt = get_post_meta($image->ID, '_wp_attachment_image_alt', true);

        if (empty($alt)) {
            $parent_post_id = $image->post_parent;
            $parent_post_title = $parent_post_id ? get_the_title($parent_post_id) : 'Δεν ανήκει σε άρθρο';
            $parent_post_url = $parent_post_id ? get_permalink($parent_post_id) : '';
            $parent_post_date = $parent_post_id ? get_the_date('d/m/Y', $parent_post_id) : 'Χωρίς Ημερομηνία';
            $parent_post_date_sort = $parent_post_id ? get_the_date('Ymd', $parent_post_id) : '0';
            $parent_post_author_id = $parent_post_id ? get_post_field('post_author', $parent_post_id) : 0;
            $parent_post_author = $parent_post_author_id ? get_the_author_meta('display_name', $parent_post_author_id) : 'Χωρίς συντάκτη';

            $images_without_alt[] = array(
                'ID'                => $image->ID,
                'Title'             => $image->post_title,
                'URL'               => wp_get_attachment_url($image->ID),
                'ParentPostID'      => $parent_post_id,
                'ParentPostTitle'   => $parent_post_title,
                'ParentPostURL'     => $parent_post_url,
                'ParentPostDate'    => $parent_post_date,
                'ParentPostDateSort'=> $parent_post_date_sort,
                'ParentPostAuthor'  => $parent_post_author,
            );
        }
    }

    // Ταξινόμηση του array κατά ημερομηνία σε φθίνουσα σειρά
    usort($images_without_alt, function($a, $b) {
        return $b['ParentPostDateSort'] <=> $a['ParentPostDateSort'];
    });

    return $images_without_alt;
}

// Συνάρτηση για την εξαγωγή
function iwat_export_images_without_alt_text() {
    // Έλεγχος δικαιωμάτων χρήστη
    if (!current_user_can('manage_options')) {
        wp_die('Δεν έχετε δικαίωμα πρόσβασης σε αυτή τη σελίδα.');
    }

    // Έλεγχος nonce
    if (!isset($_POST['export_images_nonce']) || !wp_verify_nonce($_POST['export_images_nonce'], 'export_images_without_alt_text_nonce')) {
        wp_die('Αποτυχία επαλήθευσης nonce.');
    }

    // Αποτροπή εξόδου πριν από τα headers
    ignore_user_abort(true);
    nocache_headers();
    ob_start();

    // Λήψη εικόνων χωρίς Alt Text
    $images_without_alt = iwat_get_images_without_alt_text();

    // Δημιουργία του Excel αρχείου
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Προσθήκη επικεφαλίδων
    $sheet->setCellValue('A1', 'ID Εικόνας');
    $sheet->setCellValue('B1', 'Τίτλος Εικόνας');
    $sheet->setCellValue('C1', 'URL Εικόνας');
    $sheet->setCellValue('D1', 'Τίτλος Άρθρου');
    $sheet->setCellValue('E1', 'URL Άρθρου');
    $sheet->setCellValue('F1', 'Ημερομηνία Δημοσίευσης');
    $sheet->setCellValue('G1', 'Συντάκτης');

    // Προσθήκη δεδομένων
    $row = 2;
    foreach ($images_without_alt as $image) {
        $sheet->setCellValue('A' . $row, $image['ID']);
        $sheet->setCellValue('B' . $row, $image['Title']);

        // Ορισμός του URL Εικόνας ως ενεργό hyperlink
        $sheet->setCellValue('C' . $row, $image['URL']);
        $sheet->getCell('C' . $row)->getHyperlink()->setUrl($image['URL']);
        // Προσθήκη στυλ για το hyperlink
        $sheet->getStyle('C' . $row)->applyFromArray([
            'font' => [
                'color' => ['argb' => 'FF0000FF'],
                'underline' => \PhpOffice\PhpSpreadsheet\Style\Font::UNDERLINE_SINGLE,
            ],
        ]);

        $sheet->setCellValue('D' . $row, $image['ParentPostTitle']);

        // Ορισμός του URL Άρθρου ως ενεργό hyperlink (αν υπάρχει)
        if (!empty($image['ParentPostURL'])) {
            $sheet->setCellValue('E' . $row, $image['ParentPostURL']);
            $sheet->getCell('E' . $row)->getHyperlink()->setUrl($image['ParentPostURL']);
            // Προσθήκη στυλ για το hyperlink
            $sheet->getStyle('E' . $row)->applyFromArray([
                'font' => [
                    'color' => ['argb' => 'FF0000FF'],
                    'underline' => \PhpOffice\PhpSpreadsheet\Style\Font::UNDERLINE_SINGLE,
                ],
            ]);
        } else {
            $sheet->setCellValue('E' . $row, '');
        }

        $sheet->setCellValue('F' . $row, $image['ParentPostDate']);
        $sheet->setCellValue('G' . $row, $image['ParentPostAuthor']);
        $row++;
    }

    // Ορισμός των headers για τη λήψη του αρχείου
    $filename = 'images_without_alt_text.xlsx';
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header("Content-Disposition: attachment; filename=\"$filename\"");
    header('Cache-Control: max-age=0');
    header('Expires: 0');
    header('Pragma: public');

    // Καθαρισμός του output buffer
    ob_end_clean();

    // Δημιουργία του writer και εξαγωγή
    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
    exit;
}

// Προσθήκη του action για την εξαγωγή
add_action('admin_post_export_images_without_alt_text', 'iwat_export_images_without_alt_text');
